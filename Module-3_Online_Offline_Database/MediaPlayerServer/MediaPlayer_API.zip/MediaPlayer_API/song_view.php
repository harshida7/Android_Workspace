<?php
    
    include('connect.php');
    
    $sql="select * from media_player";
    
    $r=mysqli_query($con,$sql);
    $response=array();
    
    while($row=mysqli_fetch_array($r))
    {
        
        $value["id"]=$row["id"];
        $value["song_name"]=$row["song_name"];
        $value["singer_name"]=$row["singer_name"];
        $value["song_img"]=$row["song_img"];

          array_push($response, $value);
    }
    echo json_encode($response);
    mysqli_close($con);

?>