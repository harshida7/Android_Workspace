<?php

    define('HOST','localhost');
    define('USER','id21156127_tops');
    define('PASS','Harshida@123');
    define('DB','id21156127_practice');
    
    $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to connect');

?>